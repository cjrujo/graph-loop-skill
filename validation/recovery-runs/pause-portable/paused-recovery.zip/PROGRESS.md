Graph `portable-demo` · version 1 · revision 5
Lifecycle: paused; authority: state.json

| Node | Owner | State | Dependencies | Evidence (kind/verdict) | Risk / next step |
|---|---|---|---|---|---|
| select | current-agent | succeeded | — | [files/evidence/select.json](files/evidence/select.json) (execution/pass, v1) | Reuse verified result |
| small | current-agent | succeeded | select | [files/evidence/small.json](files/evidence/small.json) (execution/pass, v1) | Reuse verified result |
| large | current-agent | skipped | select | none | Excluded branch; do not execute |
| work | current-agent | paused | small, large | none | Simulated user pause observed; no in-flight tool remains |

```mermaid
flowchart TD
  n0["select: succeeded"]
  n1["small: succeeded"]
  n0 --> n1
  n2["large: skipped"]
  n0 --> n2
  n3["work: paused"]
  n1 --> n3
  n2 --> n3
```

Snapshot validation does not prove output correctness, permissions, transition history or deadline enforcement.

Next: validate provenance, freshness, current permission, files and in-flight operations before explicit resume.
select: committed step 1; next Reuse verified result
small: committed step 1; next Reuse verified result
large: committed step 0; next Excluded branch; do not execute
work: committed step 1; next Compute immutable step 2
Missing: []
External: []
